using System;
using Godot;

public interface ISpecialSpell{
    void StartCasting(Vector3 position, Vector3 direction, Node3D caster);
    void HoldCasting(double delta);
    void HoldCasting(Vector3 position, Vector3 direction, Node3D caster, double delta);
    void EndCasting(Vector3 position, Vector3 direction, Node3D caster);
}